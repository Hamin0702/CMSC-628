package com.example.a0508classassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.amazonaws.Request;
import com.amazonaws.Response;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText filename;
    private EditText user;
    private EditText filetype;
    private Button submit;
    private File textfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        filename = (EditText) findViewById(R.id.editTextFileName);
        user = (EditText) findViewById(R.id.editTextUser);
        filetype = (EditText) findViewById(R.id.editTextFileType);
        submit = (Button) findViewById(R.id.submitbutton);

        textfile = new File(getFilesDir(), "text.txt");

        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(textfile);
            String text = "05/08 In Class Activity Reagan Armstrong & Hamin Han";
            outputStream.write(text.getBytes());
            outputStream.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        submit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String myFilename = filename.getText().toString();
        String myUser = user.getText().toString();
        String myFiletype = filetype.getText().toString();

    }

    public void uploadS3(File file, String username, String filename){
        try{
            AmazonS3 S3 = new AmazonS3Client(new DefaultAWSCredentialsProviderChain());
        } catch (Exception e){

        }
    }
}